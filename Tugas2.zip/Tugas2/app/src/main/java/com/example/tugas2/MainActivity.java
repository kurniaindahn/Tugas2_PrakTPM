package com.example.tugas2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnSubmit;
    private EditText etNama, etNim, etNilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNama = findViewById(R.id.et_nama);
        etNim = findViewById(R.id.et_nim);
        etNilai = findViewById(R.id.et_nilai);
        btnSubmit = findViewById(R.id.button);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = etNama.getText().toString();
                String nim = etNim.getText().toString();
                String nilai = etNilai.getText().toString();

                if (nama.trim().equals("")){
                    etNama.setError("Nama Tidak Boleh Kosong");
                }
                else if (nim.trim().equals("")){
                    etNim.setError("NIM Tidak Boleh Kosong");
                }
                else if (nilai.trim().equals("")){
                    etNilai.setError("Nilai Tidak Boleh Kosong");
                }
                else {
                    Intent kirim = new Intent(MainActivity.this, MainActivity2.class);
                    kirim.putExtra("kirimNama", nama);
                    kirim.putExtra("kirimNim", nim);
                    kirim.putExtra("kirimNilai", nilai);
                    startActivity(kirim);
                }

            }
        });
    }
}