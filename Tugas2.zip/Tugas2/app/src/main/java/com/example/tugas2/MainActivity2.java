package com.example.tugas2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private TextView tvNama, tvNim, tvNilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tvNama = findViewById(R.id.tv_nama);
        tvNim = findViewById(R.id.tv_nim);
        tvNilai = findViewById(R.id.tv_nilai);
        double nilai;

        Intent terima = getIntent();
        String terimaNama = terima.getStringExtra("kirimNama");
        String terimaNim = terima.getStringExtra("kirimNim");
        String terimaNilai = terima.getStringExtra("kirimNilai");

        tvNama.setText(terimaNama);
        tvNim.setText(terimaNim);

        nilai = Double.parseDouble(terimaNilai);
        if (nilai<=4.00 && nilai>3.66){
            tvNilai.setText("A");
        }
        else if (nilai<=3.66 && nilai>3.33){
            tvNilai.setText("A-");
        }
        else if (nilai<=3.33 && nilai>3.00){
            tvNilai.setText("B+");
        }
        else if (nilai<=3.00 && nilai>2.66){
            tvNilai.setText("B");
        }
        else if (nilai<=2.66 && nilai>2.33){
            tvNilai.setText("B-");
        }
        else if (nilai<=2.33 && nilai>2.00){
            tvNilai.setText("C+");
        }
        else if (nilai<=2.00 && nilai>1.66){
            tvNilai.setText("C");
        }
        else if (nilai<=1.66 && nilai>1.33){
            tvNilai.setText("C-");
        }
        else if (nilai<=1.33 && nilai>1.00){
            tvNilai.setText("D+");
        }
        else if (nilai==1.00){
            tvNilai.setText("D");
        }
    }
}